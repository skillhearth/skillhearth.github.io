# resume-bullet-rewriter (SkillHearth – free)

Paste your resume bullets. The skill rewrites each one to be clearer and more specific, shows before/after, flags vague, repeated or weak-verb bullets, and asks one short question wherever a fact is missing. It does not invent employers, titles, numbers, tools, degrees or results; missing facts appear as `[ADD: ...]`.

**How to use:** add the folder to your agent's skills location, then paste your bullets. Optionally name the target role.

**What it does not do:** it does not promise interviews or jobs, does not state country-specific resume rules, and does not write numbers you do not have.

Files: `SKILL.md`, `references/` (verb and flag guide, fictional example), `LICENSE` (MIT).

Tested on: a general-purpose AI agent, 3 fictional cases per skill; not tested on other platforms.

© SkillHearth
